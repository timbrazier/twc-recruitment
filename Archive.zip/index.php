<!--
<?php
define("EMAIL", "enquiries@eventmangementdirect.co.uk");

if(isset($_POST['submit'])) {

  include('validate.class.php');

  //assign post data to variables 
  $name = trim($_POST['name']);
  $email = trim($_POST['email']);
  $message = trim($_POST['message']);

  //start validating our form
  $v = new validate();
  $v->validateStr($name, "your name", 3, 75);
  $v->validateEmail($email, "email");
  $v->validateStr($message, "your message", 5, 1000);  

  if(!$v->hasErrors()) {
    $header = "From: $email\n" . "Reply-To: $email\n";
    $subject = "Event Management Direct Website Contact Message from $name";
    $email_to = EMAIL;

    $emailMessage = "From: " . $name . "\n";    
    $emailMessage .= "Email Address: " . $email . "\n\n";
    $emailMessage .= $message;

    //use php's mail function to send the email
    @mail($email_to, $subject ,$emailMessage ,$header );  

    //grab the current url, append ?sent=yes to it and then redirect to that url
    $url = "http". ((!empty($_SERVER['HTTPS'])) ? "s" : "") . "://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
    header('Location: '.$url."?sent=yes");

  } else {
    //set the number of errors message
    $message_text = $v->errorNumMessage();       

    //store the errors list in a variable
    $errors = $v->displayErrors();

    //get the individual error messages
    $nameErr = $v->getError("your name");
    $emailErr = $v->getError("email");
    $messageErr = $v->getError("your message");
  }//end error check
}// end isset
?>
-->

<!DOCTYPE html>
<html>
  <head>
    <title>Event Management Direct</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
    <link href="style.css" rel="stylesheet">
    <link href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  
  <body>
    <!-- <nav class="navbar navbar-default" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>

        Collect the nav links, forms, and other content for toggling
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#">About us</a></li>
            <li><a href="#">Our services</a></li>
            <li><a href="#">Meet the team</a></li>
            <li><a href="#">Our clients</a></li>
            <li><a href="#">Gallery</a></li>
            <li><a href="#">Contact us</a></li>
          </ul>  
        </div>
      </div>
    </nav> -->

    <div class="jumbotron">
      <div class="container">
        <h1><img src="images/logo.png" alt="EMD Logo" width="30%" /></h1>
          <h2>We offer a complete event planning &amp; management service</h2>
      </div>
    </div>
    
    <div id="about" class="row">
      <div class="col-md-8 col-md-offset-2 intro">
        <h3>About us</h3>
        <p>Event Management Direct is a complete event management service run by a small team of experienced event planners. EMD was setup by Jane Heppenstall in 2010 having planned the annual medical conference for VASGBI since 1996.</p>
        <br />
        <!--<button type="button" class="btn btn-primary">Read more about us</button>-->
      </div>
    </div>

    <div id="services" class="row">
      <div class="col-md-8 col-md-offset-2 intro">
        <h3>Our services</h3>
        <p>We can help you plan your perfect event or conference tailored to your specific needs. We are experienced in organising:</p>
        <br />  
        <ul class="col-md-6 col-md-offset-4">
          <li><i class="fa fa-chevron-right"></i>Conferences &amp; meetings <br />  (specialising in medical events)</li>
          <li><i class="fa fa-chevron-right"></i>Christmas parties</li>
          <li><i class="fa fa-chevron-right"></i>Charity events</li>
          <li><i class="fa fa-chevron-right"></i>Birthday parties</li>
          <li><i class="fa fa-chevron-right"></i>and much more.</li>
        </ul>
        <br />
        <!--<button type="button" class="btn btn-primary">Read more about our services</button>-->
      </div>
    </div>

    <div id="contact" class="row">
      <div class="col-md-8 col-md-offset-2">
        <h3>Get in touch</h3>
        <p><span>If you would like to enquire about how Event Management Direct can help you and your event, you can call <em>0114 2455 423</em> or send us a message using the form below</span></p>
        <br />
        <div id="contact-form">
        <span class="message"><?php echo $message_text; ?></span>
        <?php if(isset($_GET['sent'])): ?><h4><i class="fa fa-check-circle-o"></i> Your message has been sent</h4><?php endif; ?>
        <form id="contact_form" class="clear" method="post" action="#">
          <p><label>Your name:<br />
            <input type="text" name="name" class="textfield" size="40" value="<?php echo htmlentities($name); ?>" />
          </label><br /><span class="errors"><?php echo $nameErr; ?></span></p>

          <p><label>Your email address: <br />
            <input type="text" name="email" class="textfield" size="40" value="<?php echo htmlentities($email); ?>" />
          </label><br /><span class="errors"><?php echo $emailErr ?></span></p>          

          <p><label>Your message: <br />
            <textarea name="message" class="textarea" cols="40" rows="5"><?php echo htmlentities($message); ?></textarea>
          </label><br /><span class="errors"><?php echo $messageErr ?></span></p>

          <p><input type="submit" size="400" name="submit" class="button" value="Submit" /></p>
        </form>
      </div>
      </div>
    </div>

    <div id="clients" class="row">
      <div class="col-md-8 col-md-offset-2 clients">
        <h3>Some of our clients</h3>
        <ul>
          <li><img src="images/vas-logo.png" alt="VASGBI logo"></li>
          <li><img src="images/acta-logo.png" alt="VASGBI logo"></li>
          <li><img src="images/nasgbi-logo.png" alt="VASGBI logo"></li>
          <li><img src="images/siva-logo.png" alt="VASGBI logo"></li>
        </ul>
      </div>
    </div>

   <!--  <div class="row">
      <div class="col-md-8 col-md-offset-2 gallery">
        <h3>Gallery</h3>
        <style type="text/css"> 
          .flickrimg {border: 0px solid #666666 !important; padding:2px; margin:6px;}
          #flickr_badge_wrapper {width:900px;text-align:left}
          </style><div id="flickr_badge_wrapper"><script type="text/javascript" src="http://www.flickr.com/badge_code.gne?count=18&display=latest&size=square&nsid=7745923@N07&raw=1"></script></div>  
      </div>
    </div> -->

    <div class="row">
      <div class="col-md-12 footer">
        <ul>
          <li><a href="http://www.twitter.com/Event_M_Direct"><i class="fa fa-twitter fa-3x"></i></a></li>
          <li><a href="http://www.facebook.com/eventmanagementdirect"><i class="fa fa-facebook fa-3x"></i></a></li>
          <!-- <li><i class="fa fa-flickr fa-3x"></i></li> -->
        </ul>
        <br />
        <p>Event Management Direct is a Limited company incorporated in England and Wales (No. 08409156)</p>
      </div>
    </div>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  
  </body>
</html>